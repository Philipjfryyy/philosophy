

let input = prompt("What is the meaning of life?")
input = input.toLowerCase();
if (input == "to party") {
    alert("You're an animal!");
} else if (input == "forty-two" || input == "forty two" || input == "42") {
    alert("Ah, that is the ultimate answer, but what is the ultimate question?");
}  else if (input == "feet") {
    alert("Weird!");
} else if (input == "sirens") {
    alert("okay Homer");
} else if (input == "goblins") {
    alert("okay so dnd?");
} else if (input == "dracula") {
    alert("the ravings of a demented Irishman.");
} else if (input == "some kind of potato man") {
    alert("the lord of all things.");
} else if (input == "squirt") {
    alert("Amrita, nectar of the gods, a delicious grapefruit soda!");
} else if (input == "peace") {
    alert("good answer.");
} else if (input == "eggs") {
    alert("I mean, they're pretty good, but, the 'best thing?' No.");
} else if (input == "food") {
    alert("No arguments here!");
} else if (input == "salmon") {
    alert("Yum.");
} else if (input == "pasta") {
    alert("Yes, but with a Mario-like accent.");
} else if (input == "water") {
    alert("I mean, yeah, not very imaginitive, but technically correct.");
} else if (input == "love") {
    alert("Well, isn't that a nice answer?");
} else if (input == "sleep") {
    alert("Got it, go talk to morpheus.");
} else if (input == "dune" || input == "dune.") {
alert("The spice must flow.");
} else if (input == "beauty") {
    alert("Go see if Narcissus has any openings.");
} else if (input == "art") {
    alert("Where's that muse?");
} else if (input == "books") {
    alert("Yeah, good answer, but what genre? Cuz if you only read textbooks on different types of soil, you need to get out more.");
} else if (input == "animals") {
    alert("Man is a animal. -Aristotle misquoted");
} else if (input == "people") {
    alert("No. I mean some are pretty cool, but overall, no.");
} else if (input == "music") {
    alert('"The great communicator, use two sticks to make it in the nature!"');
} else if (input == "nature") {
alert("Yay neature!");
} else if (input == "big flopping donkey ears.") {
alert("Why are you like this?");
} else if (input == "what is the ultimate question?") {
    alert("What do you get when you multiply six by seven?");
} else if (input == "golf") {
    alert("Hole in one!");
} else if (input == "sports") {
    alert("Go team!");
} else if (input == "god") {
    alert("How pious.");
} else if (input == "video games") {
    alert("well said");
} else if (input == "existing") {
    alert("You're not wrong!");
} else if (input == "to live") {
    alert("“The meaning of life is just to be alive. It is so plain and so obvious and so simple. And yet, everybody rushes around in a great panic as if it were necessary to achieve something beyond themselves -Alan Watts");
} else if (input == "there is no meaning") {
    alert("Ah, nihilism.");
} else if (input == "to learn" || input == "learning") {
    alert("Lao Tzu approves");
} else if (input == "to reproduce") {
    alert("That's arguably correct on a technical level.");
} else if (input == "i don't know" || input == "i dont know" || input == "idk") {
    alert("How very Ajnana of you.");
} else if (input == "to pass on knowledge" || input == "To pass on knowledge") {
    alert("Find something to believe in, and find it for yourself. When you do, pass it on to the future. -Solid Snake");
} else if (input == "family") {
    alert("Heartwarming answer."); 
} else if (input == "pizza") {
    alert("Anything is pizza, so long as it is flat.");
    } else if (input =="nothing") {
        alert("Hopefully that's cheerful nihilism");
    } else if (input == "cheeseburgers") {
        alert("Yum!");
    } else {
alert("On second thought, let’s not go to Camelot. ‘Tis a silly place");
    }



