# odin-recipes
A website that contains recipes and links to them. Update: The Odin Project said to go back and soup up this website. I don't really care about recipes, so I remade it to be about philosophy. Enjoy.
